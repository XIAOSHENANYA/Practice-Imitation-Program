// pages/video/video.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    MV:0,
    U1:"http://vodkgeyttp8.vod.126.net/cloudmusic/obj/core/2749774477/35f32d33701fb8813e3ce0f9b44acb3c.mp4?wsSecret=4f6f047ca6a9cf6dea390275ebe5c677&wsTime=1669098659",
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.showVieo();
  },
  showVieo:function(){
    wx.request({
      url: '{http://music.163.com/api/mv/detail?id='+'10930368'+'&type=mp4}',
      success(res){
        console.log(res)
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})