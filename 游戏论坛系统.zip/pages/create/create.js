// pages/create/create.js
const app=getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // id:"4",
    title:"",
    info: "",
    name:"",
    sort:"",
    url:"",
    img:"",
    listdata:[{ 
    id:4,    
    title:"《原神》3.5版本是几月几号更新？3.5版本更新方式介绍",
    img:"https://tse2-mm.cn.bing.net/th/id/OIP-C.-Zotm5xNxUXRx6sEzIagMwHaE7?pid=ImgDet&rs=1",
    info:"移动端进行预下载，会提前下载部分新资源，加快版本更新后在登录界面的资源下载进度，减少资源下载消耗的时间。在版本更新时，iOS设备仍需要进入App Store，点击更新。安卓设备需要设备进入游戏，按照游戏内弹窗提示完成更新或进入应用商店，点击更新移动端的旅行者在预下载时无法进行游戏，建议旅行者在完成秘境或各种挑战后再进行操作。",
    name:"原神",
    sort:"角色扮演",
    num:"0"}],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },
  // 信息填入,同页面参数传递
  bindTitle: function(e) {
    // console.log(e.detail.value)
    this.setData({
      title:e.detail.value
    })
  },
  bindContent: function(e) {
    // console.log(e.detail.value)
    this.setData({
      info:e.detail.value
    })
  },
  bindName: function(e) {
    // console.log(e.detail.value)
    this.setData({
      name:e.detail.value
    })
  },
  bindKind: function(e) {
    // console.log(e.detail.value)
    this.setData({
      sort:e.detail.value
    })
  },
  // 图片上传
  chooseImg:function(e){
    const that=this
    wx.chooseMedia({
      count: 1,
      mediaType: ['image'],
      sourceType: ['album', 'camera'],
     
      success(res) {
        // console.log(res.tempFiles[0].tempFilePath)
        const url=res.tempFiles[0].tempFilePath
        // console.log(url)
        that.setData({
          img:url
        })
      }
    })
  },
  //确认发布
   creatework:function(){
        let title=this.data.title
        let img=this.data.img
        let info=this.data.info
        let name=this.data.name
        let sort=this.data.sort
        this.setData({
          ['listdata.id']:4,
          ['listdata.title']:title,
          ['listdata.img']:img,
          ['listdata.info']:info,
          ['listdata.name']:name,
          ['listdata.sort']:sort,
          ['listdata.num']:0,
        });
    //     console.log(this.data.listdata)
        var list=app.globalData.list.concat(this.data.listdata)
        app.globalData.list=list
    var Storage=app.globalData.StorageData.concat(this.data.listdata)
    app.globalData.StorageData=Storage
        console.log(app.globalData.StorageData) 
    // wx.setStorageSync('listdata', this.data.listdata)
    // wx.navigateTo({
    //   url: '../my-work/my-work.wxml',
    // })
      },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})