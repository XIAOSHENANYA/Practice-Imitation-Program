// pages/index/index.js
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    navH: 0,
    bgimg:"/images/背景1.jpg",
    imgList:["https://t1.g.mi.com/thumbnail/jpeg/w980h90/AppStore/08d70ed9e2273440bb931faa7f3e3a7f69354c3d1","https://game.gtimg.cn/images/yxzj/cp/a20170829bbgxsm//lb_30.jpg","https://img.hackhome.com/img2016/7/25/2016072557512865.jpg","https://cdn.max-c.com/heybox/game/header/668580_ZjVSY.jpg","https://img.3dmgame.com/uploads/allimg/170523/316-1F523102612.jpg"],
    list: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      navH: app.globalData.navHeight,
      list:app.globalData.list
    });
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
onShow: function() {
		var listdata = app.globalData.list;;

		this.data.list=listdata

	},

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {
    var listdata = app.globalData.list;
		this.setData({
			list: listdata
		})
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})