// pages/serach/search.js
var app=getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    navH: 0,
    isSearch:true,
    isClear:false,
    val:'',
    list:[],
    
  },
//   handleFruitChange({ detail = {} }) {
//     this.setData({
//         current: detail.value
//     });
// },
  // formSubmit: function (e) {

  //   this.upload(e)
  // },

  /**
   * 生命周期函数--监听页面加载
   */

  onLoad: function (options) {
    this.setData({
      navH: app.globalData.navHeight
    });
    
  },
  inputTyping: function(e) {
    console.log("input-----",e)
    var value = e.detail.value
    var that = this;
    var usersList = app.globalData.list
    if (value == '') {
      that.setData({
        usersFlag:true,
        searchFlag:false
      });
    } else {
        var arr = [];
        for (var i = 0; i < usersList.length; i++) {
          if (usersList[i].name.indexOf(value) >= 0) {
            arr.push(usersList[i]);
          }
        }
        console.log(arr)
        that.setData({
          usersFlag:false,
         searchFlag:true,
          list: arr
        });
        // console.log(that.data.usersFlag)
    }
  },


  getInput:function(e){
    this.setData({
      val:e.detail.value
    })
    console.log(this.data.val)
    var editItem = app.globalData.list.find((ele) => {
      return ele.name == this.data.val
      })  
    if(this.data.val.length>0){
      this.setData({
        isSearch:false,
        isClear:true,
      })
    }else{
      this.setData({
        isSearch:true,
        isClear:false,
      })
    }
  },
  clearTap:function(){
    this.setData({
      val:'',
      isSearch:true,
      isClear:false
    })
  },
  
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})