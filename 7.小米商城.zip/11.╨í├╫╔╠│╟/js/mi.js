// 获取car的div元素对象
$(".car")
// 法一
.mousemove(function(){
    //1.设置图片切换为橙色
    $(".car img").attr("src","./images/01.ico")
    //2.设置字体为橙色
    $(".car a").css("color","#ff6700");
    //b设置背景颜色为白色
    $(".car").css("background-color","#fff")
    $(".carlist").stop().slideDown(200);
})
.mouseout(function(){
    //1.设置图片切换为白色
    $(".car img").attr("src","./images/02.ico")
    //2.设置字体为白色
    $(".car a").css("color","#888888");
    //b设置背景颜色为黑色
    $(".car").css("background-color","#424242")
    $(".carlist").stop().slideUp(200);
})
// 法二
//slideDown(s):向下滑动显示效果，s为时间，毫秒
//slideUp(s):向上滑动显示效果，s为时间，毫秒
// .mouseenter(function(){
//     $(".carlist").slideDown(50);
//     //1.设置图片切换为橙色
//     $(".car img").attr("src","./images/01.ico")
//     //2.设置字体为橙色
//     $(".car a").css("color","#ff6700");
//     //b设置背景颜色为白色
//     $(".car").css("background-color","#fff")
// })
// .mouseleave(function(){
//     $(".carlist").slideUp(50);
//     //1.设置图片切换为橙色
//     $(".car img").attr("src","./images/02.ico")
//     //2.设置字体为橙色
//     $(".car a").css("color","#888888");
//     //b设置背景颜色为白色
//     $(".car").css("background-color","#424242")
// })
//APP下载
$(".App")
.mousemove(function(){
    $(".AppBox").css("display","block")
})
.mouseout(function(){
    $(".AppBox").css("display","none")
})
//导航下拉菜单
$(".tool li")
.mouseenter(()=>{
    getData();
    var index=$(this).index();
    console.log(index);
    if(index<7){
        $(".toollist").stop().slideDown(200);
    }else{
        $(".toollist").stop().slideUp(200);
    }
})
.mouseleave(()=>{

    $(".toollist").stop().slideUp(200);
    })

$(".toollist")
    .mouseenter(()=>{
        $(".toollist").stop().slideDown(200);
    })

    .mouseleave(()=>{
        $(".toollist").stop().slideUp(200);
    })

// 左导航显示列表
// 鼠标经过左菜单出商品
$(".leftBox li")
  .mousemove(function(){
    // leftData();
    $(".rightList").css("display","block")
  })
  .mouseout(function(){

    $(".rightList").empty();
    $(".rightList").css("display","none")
  })
$(".rightList").mouseenter(() => {
    $(".rightList").stop().slideDown(0);
}).mouseleave(() => {
    $(".rightList").stop().slideUp(0);
})




//轮播
var index=0;
var nextIndex=0;
var timer;
function animationPlay(){
    // $("").eq(index).fadeOut(500);
    // $(".carousBox img").eq(nextIndex).fadeIn(500);
    //滑动播放
    if(index<nextIndex){
        //正在移动一张图片
        $(".carousBoxImg").eq(index).stop().animate({left:"-1226px"},500)
        //移动下一张图片
        $(".carousBoxImg").eq(nextIndex).css("left","1226px").stop().animate({left:"0px"},500)
    }else if(index>nextIndex){
        $(".carousBoxImg").eq(index).stop().animate({left:"1226px"},500)
        $(".carousBoxImg").eq(nextIndex).css("left","-1226px").stop().animate({left:"0px"},500)
    }
    // 获取小圆点对象 下一张背景颜色显示，前一张背景颜色去掉
    $(".carousBoxList li")
    .eq(nextIndex).stop()
    .addClass("one")//添加类样式
    .siblings()//过滤
    .removeClass('one');//移除类样式;
}
//循环播放
autoplay();
function autoplay(){
    timer=setInterval(function(){
        if(nextIndex>=2){
            nextIndex=0;
            index=-1;
        }else{
            nextIndex++;
        }
        animationPlay();
        index=nextIndex;
    },2000)
}
//鼠标点击小圆点
$(".carousBoxList li").click(function(){
    clearInterval(timer);
//获取当前点击的下表
    nextIndex=$(this).index();
    animationPlay();//轮播
    index=nextIndex;
    autoplay();
})
//小圆点
function playImage(n){
    $(".carousBoxList li").removeClass("one").siblings().eq(n).addClass("one");
}
//鼠标点击左箭头
$(".leftButton").click(function(){
    if(nextIndex>0){
        nextIndex--;
    }else{
        nextIndex=2;
        index=3;
        $(".carousBoxImg").eq(0).css("left", "0px").stop().animate({ left: "1226px" }, 500);
    }
    animationPlay();
    index=nextIndex;
    clearInterval(timer);
    autoplay();
})
//鼠标点击右箭头
$(".rightButton").click(function(){
    if(nextIndex<2){
        nextIndex++;
    }else{
        nextIndex=0;
        index=-1
    }
    animationPlay();
    index=nextIndex;
    clearInterval(timer);
    autoplay();
})
