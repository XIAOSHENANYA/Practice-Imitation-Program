var XmImgs=["Xiaomi01.png","Xiaomi02.png","Xiaomi03.png","Xiaomi04.png","Xiaomi05.png","Xiaomi06.png"];
var HmImgs=["Xiaomi01.png","Xiaomi03.png","Xiaomi01.png","Xiaomi06.png","Xiaomi05.png","Xiaomi04.png"];
var DsImgs=["dianshi01.png","dianshi01.png","dianshi02.png","dianshi03.png","dianshi04.png","dianshi05.png"]
var PbImgs=["diannao01.png","diannao02.png","diannao02.png","diannao01.png","diannao02.png","diannao03.png"]
var JdImgs=["pingban01.png","pingban02.png","pingban03.png","pingban03.png","pingban03.png"]
var LyImgs=["jiadian.png"];

var XmNames=["Xiaomi Civil1","Xiaomi Mix Fold2","Xiaomi 12,Xiaomi Pro","Xiaomi12 Pro","Xiaomi12 天机","Xiaomi 12"]
var HmNames=["Xiaomi Civil1","Xiaomi Mix Fold2","Xiaomi 12,Xiaomi Pro","Xiaomi12 Pro","Xiaomi12 天机","Xiaomi 12"]
var DsNames=["Redmi Note 5G","Redmi Note 5G","Redmi Note 5G","Redmi Note 5G","Redmi Note 5G","Redmi Note 5G"]
var PbNames=["Redmi Note 5G","Redmi Note12","Redmi Note Pro","Redmi Note 5G","Redmi Note12","Redmi Note Pro"]
var JdNames=["Redmi Note 5G","Redmi Note12","Redmi Note Pro","Redmi Note Mix","Redmi Note 天机"]
var LyNames=["JiaDian S12"]

var Xmrmbs=["￥2228","￥2228","￥2568","￥3228","￥5628","￥2568"]
var Hmrmbs=["￥2228","￥2568","￥2828","￥2228","￥2228","￥2228"]
var Dsrmbs=["￥2256","￥3428","￥2228","￥2228","￥2228","￥2228"]
var Pbrmbs=["￥2257","￥2228","￥2228","￥2228","￥2228","￥2228"]
var Jdrmbs=["￥2856","￥2228","￥2228","￥2228","￥2228"]
var Lyrmbs=["￥2239"]

var ImgList=[];
var NameList=[];
var RmbList=[];


function getData(){
    $(".toollistCon").empty();
    console.log("-----------------------------------");
    for(var i=0;i<6;i++){
        var goodDiv = $("<div class='goodsDiv'></div>");
        $(".toollistCon").append(goodDiv);
        //定义图片
        var goodsImg = $("<img class='goodsImg' />");
        //将图片加入div中
        goodDiv.append(goodsImg);
        //文字
        var goodsName = $("<p class='goodsName'></p>");
        //将文字加入到div中
        goodDiv.append(goodsName);
        //价格
        var goodsRmb = $("<p class='goodsRmb'></p>");
        //将加入加入div中
        goodDiv.append(goodsRmb);
    }  
}

$(".tool li")
.mouseenter(function(){
    
    var index=$(this).index();
    if(index==0){
        ImgList=XmImgs;
        NameList=XmNames;
        RmbList=Xmrmbs;
    }else if(index==1){
        ImgList=HmImgs;
        NameList=HmNames;
        RmbList=Hmrmbs;
    }else if(index==2){
        ImgList=DsImgs;
        NameList=DsNames;
        RmbList=Dsrmbs;
    }else if(index==3){
        ImgList=PbImgs;
        NameList=PbNames;
        RmbList=Pbrmbs;
    }else if(index==4){
        ImgList=JdImgs;
        NameList=JdNames;
        RmbList=Jdrmbs;
    }else if(index==5){
        ImgList=LyImgs;
        NameList=LyNames;
        RmbList=Lyrmbs;
    }else if(index==6){
        ImgList=LyImgs;
        NameList=LyNames;
        RmbList=Lyrmbs;}

    else{
        $(".toollist").stop().slideUp(200);
        console.log(">7")
    }
    getData();
    for(var i=0;i<ImgList.length;i++){
        
        var box=$(".goodsDiv").eq(i);
        box.children(".goodsImg").attr("src","./images/"+ImgList[i]);
        box.children(".goodsName").text(NameList[i]);
        console.log(NameList[i])
        box.children(".goodsRmb").text(RmbList[i]);
    }
})
//左点机框

var sjImg1=["xsj01.png","xsj02.png","xsj03.png","xsj04.png","xsj05.png","xsj06.png","xsj07.png","xsj08.png"];
var sjName1=["Redmi Note 12 5G","Redmi Note 12 Pro","Redmi Note 12 Pro+","Redmi Note 11 5G","Redmi K50","Redmi Note 11T Pro","Xiaomi 12S Pro","Redmi K50 至尊版"];
var sjImg2=["xsj01.png","xsj02.png","xsj03.png","xsj04.png","xsj05.png","xsj06.png","xsj07.png","xsj08.png"];
var sjName2=["Redmi Note 12 5G","Redmi Note 12 Pro","Redmi Note 12 Pro+","Redmi Note 11 5G","Redmi K50","Redmi Note 11T Pro","Xiaomi 12S Pro","Redmi K50 至尊版"];
var sjImgList=[];
var sjNameList=[];
function leftData(){
    $(".rightList").empty();
    
    for(var i=0;i<sjImgList.length;i++){
        var sjDiv=$("<div class='sjDiv'></div>");
        $(".rightList").append(sjDiv);
        var sjImg = $("<img class='sjImg' />");
        //将图片加入div中
        sjDiv.append(sjImg);
        //文字
        var sjName = $("<p class='sjName'></p>");
        //将文字加入到div中
        sjDiv.append(sjName);
    }
}
$(".leftBox li")
.mouseenter(function(){
    console.log(leftData)
    var index=$(this).index();
    if(index==0){
        sjImgList=sjImg1;
        sjNameList=sjName1;
    }else if(index==1){
        sjImgList=sjImg2;
        sjNameList=sjName2;
    }
    leftData();
    for(var i=0;i<sjImgList.length;i++){
        var box=$(".sjDiv").eq(i);
        box.children(".sjImg").attr("src","./images/"+sjImgList[i]);
        box.children(".sjName").text(sjNameList[i]);
        console.log(sjNameList[i])
    }
})





//手机区域
var smImg=["sjs01.png","sjs02.png","sjs03.png","sjs04.png","sjs05.png","sjs06.png","sjs07.png","sjs08.png"];
var smName=["Redmi Note 12 5G","Redmi Note 12 Pro","Redmi Note 12 Pro+","Redmi Note 11 5G","Redmi K50","Redmi Note 11T Pro","Xiaomi 12S Pro","Redmi K50 至尊版"]
var smText=["三星 OLED 护眼屏｜骁龙 5G 芯｜5000mAh 电量"," IMX766 防抖相机｜OLED 柔性直屏｜67W 闪充","2亿超清防抖相机｜OLED 柔性直屏","5000mAh大电量","2K直屏的狠旗舰","天玑8100｜真旗舰芯","骁龙8+ 旗舰处理器 | 徕卡影像","骁龙8+ ｜1.5K 高清直屏"]
var smRmb=["1199元起","1199元起","2199元起","1199元起","2299元起","1569元起","4399元起","2999元起"];
// var smImgList=[];
// var smNameList=[];
// var smTextList=[];
// var smRmbList=[];
goodsStart();
function goodsStart(){



    for(var i=0;i<smImg.length;i++){
    var gDiv=$("<div class='gDiv'></div>");
    $(".right2").append(gDiv);
    var gImg=$("<img class='gImg' />");
    gDiv.append(gImg);
    var gName=$("<div class='gName'></div>");
    gDiv.append(gName);
    var gText=$("<h class='gText' text-overflow: ellipsis></h>")
    gDiv.append(gText);
    var gRmb=$("<h class='gRmb' text-overflow: ellipsis></h>")
    gDiv.append(gRmb);
    var box=$(".gDiv").eq(i);
    box.children(".gImg").attr("src","./images/"+smImg[i]);
    box.children(".gName").text(smName[i]);
    console.log(smName[i])
    box.children(".goodsRmb").text(smRmb[i]);
    }
    
}
