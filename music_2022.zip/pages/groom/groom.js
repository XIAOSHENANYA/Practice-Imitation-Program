// pages/groom/groom.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 定义搜索关键字
    kw:[],
    //定义歌曲信息数组
    songs:[],
    //定义存储图片的变量
    picUrl:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },
  // 获取文本框输入值
  getKeyWord:function(e){
    
    var keyword=e.detail.value;
    // 给data中的kw赋值
    this.setData({
      kw:keyword
    })
    },
  // 获取封面的方法
  getMusicImage:function(searchIds,i,length){
    // console.log("e");
    //获取data中的图片数组
    var pic=this.data.picUrl;
    var that=this
    wx.request({
      url: 'https://music.163.com/api/song/detail/?id='+searchIds[i]+'&ids=['+searchIds[i]+']',
      success:function(res){
        // console.log(res)
        var img=res.data.songs[0].album.blurPicUrl;
        //将封面添加到data中
        pic.push(img);
        that.setData({
          picUrl:pic
        })
      }
    })
    //判断 ++i先计算后赋值 i++先赋值后计算
    if(++i<length){
      that.getMusicImage(searchIds,i,length)
    }
  },
// 根据kw的值找出对应的歌曲的信息存储到songs中，界面上遍历songs 
do_search:function(){
  //1.获取data中的关键字
  var kw=this.data.kw;
  //从网易云的后端服务器中获取数据
  //首先发送请求
  var that=this;
  // 定义存储歌曲的id
  var searchIds=[]
  wx.request({
    url: 'https://music.163.com/api/search/get?s='+kw+'&type=1&limit=6',
    // 如果响应成功，则
    success:function(res){
      var resultSongs=res.data.result.songs;
      for(var i=0;i<resultSongs.length;i++){
        // var searchId=resultSongs[i].id;
        searchIds.push(resultSongs[i].id);
      }
      //清空封面数组
      that.setData({
        picUrl:[]
      })
      //调用获取封面的方法
      that.getMusicImage(searchIds,0,searchIds.length);
      //将获取得到的数据赋值给data中的songs中
      that.setData({
        songs:resultSongs
      })
    }
    
  })
  //2.定义空的数字存储搜索出来的所有的歌曲ID
  var searchId=[];
  //3.定义歌曲的名称数组
  var names=[];
  //4.定义储存歌手的id的数组
  var songerId=[];
},
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },
// 跳转到播放页面
gotoPlay:function(e){
  // 获取列表id的数组
  var ids=[];
  // 从data中获取songs push将内容添加到数组
  for(var i=0;i<this.data.songs.length;i++){
    ids.push(this.data.songs[i].id)
  }
  var id=e.currentTarget.dataset.id;
  // console.log(ids);
  wx.navigateTo({
    url: '/pages/play/play?mid='+id+"&ids="+ids,
  })
},
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})