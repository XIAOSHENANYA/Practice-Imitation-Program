// pages/index/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imgList:[
      "	https://p1.music.126.net/qnH_9VW4J0jZctZhR3Ld4Q==/109951168063208816.jpg?imageView&quality=89",
      "https://p1.music.126.net/YECBnxSI6gS9rIlXm5KuIw==/109951168062892024.jpg?imageView&quality=89",
      "https://p1.music.126.net/pg_QaXAdzuTbJ5gIbzCDag==/109951168062920517.jpg?imageView&quality=89",
      "https://p1.music.126.net/v_VnChSfVtEXsJlnLD5Qww==/109951168063017788.jpg?imageView&quality=89"
    ],
    songList:{
      songImg:["https://p1.music.126.net/_Ej6TahANI-aqsJCTf7uCA==/109951163240060789.jpg?param=140y140","https://p1.music.126.net/_Ej6TahANI-aqsJCTf7uCA==/109951163240060789.jpg?param=140y140","https://p1.music.126.net/_Ej6TahANI-aqsJCTf7uCA==/109951163240060789.jpg?param=140y140","https://p1.music.126.net/_Ej6TahANI-aqsJCTf7uCA==/109951163240060789.jpg?param=140y140","https://p1.music.126.net/_Ej6TahANI-aqsJCTf7uCA==/109951163240060789.jpg?param=140y140"],
      songName:["好听到爆欧美音乐合集（评论过万）","好听到爆欧美音乐合集（评论过万）","好听到爆欧美音乐合集（评论过万）","好听到爆欧美音乐合集（评论过万）","好听到爆欧美音乐合集（评论过万）"]
    },
    rank:[
      {
      name:"云音乐热歌榜",
      ranksong:[{
        id:"1",
        imgurl:"https://p2.music.126.net/POwgpwBtxaK37DF70FWjqg==/109951167677013080.jpg",
        musicName:"情歌"
      },
      {
        id:"2",
        imgurl:"https://p2.music.126.net/POwgpwBtxaK37DF70FWjqg==/109951167677013080.jpg",
        musicName:"情歌"
      },
      {
        id:"3",
        imgurl:"https://p2.music.126.net/POwgpwBtxaK37DF70FWjqg==/109951167677013080.jpg",
        musicName:"情歌"
      }]
      },
      { 
        name:"云音乐热歌榜",
        ranksong:
        [
          {
          id:"1",
          imgurl:"https://p2.music.126.net/POwgpwBtxaK37DF70FWjqg==/109951167677013080.jpg",
          musicName:"情歌"
          },
          {
          id:"2",
          imgurl:"https://p2.music.126.net/POwgpwBtxaK37DF70FWjqg==/109951167677013080.jpg",
          musicName:"情歌"
          },
          {
          id:"3",
          imgurl:"https://p2.music.126.net/POwgpwBtxaK37DF70FWjqg==/109951167677013080.jpg",
          musicName:"情歌"
          }
        ]
      },
      {
          name:"云音乐热歌榜",
          ranksong:[
          {
            id:"1",
            imgurl:"https://p2.music.126.net/POwgpwBtxaK37DF70FWjqg==/109951167677013080.jpg",
            musicName:"情歌"
          },
          {
            id:"2",
            imgurl:"https://p2.music.126.net/POwgpwBtxaK37DF70FWjqg==/109951167677013080.jpg",
            musicName:"情歌"
          },
          {
            id:"3",
            imgurl:"https://p2.music.126.net/POwgpwBtxaK37DF70FWjqg==/109951167677013080.jpg",
            musicName:"情歌"
          }]
      }
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },
// 跳转到当日页面
groomTap:function(){
  //页面跳转
  wx.navigateTo({
    url: '/pages/groom/groom',
  })
},
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})