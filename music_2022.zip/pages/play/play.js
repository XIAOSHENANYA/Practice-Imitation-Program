// pages/play/play.js
// 创建音频对象
var innerAudioContext=wx.createInnerAudioContext();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    state:"play",
    song:null,//当前获取的songs变量
    songWord:null,//获取当前歌词
    ids:[],//存储当前播放列表的所有id
    id:0,//存储当前歌曲的id
    lyricArray:null,//歌词词组
    currentIndex:0,//当前正在播放的行号
    scrollTop:0,//歌词滚动的偏移量,竖向滚动的位置
    playTime:"",//开始时间
    endTime:"",//总时间
    duration:"",
    currentTime:"",
  },
  
  
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    // 接受传递过来的id
    var id=options.mid;
    //接受传递过来的ids
    var ids=options.ids;
    // console.log(ids);
    // 将字符串拆分Split("") 得到的是一个数组
    ids=ids.split(",");
    this.playMusic(id,ids);
  },
  playMusic:function (id,ids) {
    this.setData({
      ids:ids,
      id:id
    })
// 1.给音频src赋值
  innerAudioContext.src='http://music.163.com/song/media/outer/url?id='+id+'.mp3',
  // 2.设置自动播放
  innerAudioContext.autoplay=true,
  // 3.调用播放方法
  innerAudioContext.play();
  // 通过id获取当前歌曲详情的函数
  this.getMusicById(id);

  // this.getMusicWord(id);
  this.getLyricById(id);
// 监听音频进入可以播放状态的时间
innerAudioContext.onCanplay(()=>{
  // 音频的时长
  var duration=innerAudioContext.duration;
})
// 监听音频播事件更新
/* 现调用onCanplay之后,onTimeUpdate才会有作用**/ 
innerAudioContext.onTimeUpdate(()=>{
  // 调用歌词滚动函数
  this.lyricScroll();
  this.sliderChange();
})
  },
  /** 完成一次拖动后触发的方法*/
  dragSlider:function(e){
    //获取进度条拖动后的值
    var value=e.detail.value;
    //修改音频的进度
    innerAudioContext.seek(value);
  },
  /**进度条*/
  sliderChange:function(){
    //获取当前音频的进度条和总长度
    var currentTime=innerAudioContext.currentTime;
    var duration=innerAudioContext.duration;
    //currentTime换位分秒为单位
    var playMinute=Math.floor(currentTime/60);
    var playSeconds=Math.floor(currentTime%60);
    //换算为总时长
    var endMinute=Math.floor(duration/60);
    var endSeconds=Math.floor(duration%60);
    playMinute=playMinute>9?playMinute:"0"+playMinute;
    playSeconds=playSeconds>9?playSeconds:"0"+playSeconds;
    endMinute=endMinute>9?endMinute:"0"+endMinute;
    endSeconds=endSeconds>9?endSeconds:"0"+endSeconds;
    this.setData({
      currentTime:currentTime,
      duration:duration,
      playTime:playMinute+":"+playSeconds,
      endTime:endMinute+":"+endSeconds
    })
  },
  playOrplause:function(){
    var musicState=this.data.state
    if(musicState=="play"){
      innerAudioContext.pause();
      this.setData({
        state:"pause"
      })
    }else{
      innerAudioContext.play();
      this.setData({
        state:"play"
      })
    }
  },
// 通过歌曲ID获取歌曲详情
getMusicById:function(id){
  var that=this;
  wx.request({
    url: 'https://music.163.com/api/song/detail/?id='+id+'&ids=['+id+']',
    success:function(res) {
      //res:服务器根据请求给出的响应
      // console.log(res);
      
      var result=res.data.songs[0];
      //将result赋值给data中的song变量
      //异步请求
      that.setData({
        song:result
      })
    }
  })
},
// getMusicWord:function (id) {
//   var that=this;
//   wx.request({
//     url: 'http://musicapi.leanapp.cn/album/detail/dynamic?id= '+id+'',
//     success:function(re) {
//       console(re)
//     }
//   })
// },
  // 上一首
  // 思路：根据当前歌曲id，找到当前歌曲的对应下表，根据下表找到上一首歌曲的id
  prev:function () {
    // 1.获取所有的歌曲的id和当前播放的歌曲的id
    var ids=this.data.ids;
    var id=this.data.id;
    // 2.记录当前歌曲的下标
    var index=0;
    for(var i=0;i<ids.length;i++){
      if(id==ids[i]){
        index=i;

      }
    }
    // 上一首歌曲的下表
    var prevIndex=index==0?ids.length-1:index-1;
    // 播放
    this.playMusic(ids[prevIndex],ids);
  },
  // 下一首
  next:function () {

        var ids=this.data.ids;
        var id=this.data.id;

        var index=0;
        for(var i=0;i<ids.length;i++){
          if(id==ids[i]){
            index=i;
    
          }
        }

        var nextIndex=index==ids.length-1?0:index+1;
        // 播放
        this.playMusic(ids[nextIndex],ids);
  },
  // 根据id获取歌词
  getLyricById:function(id){
    var that=this;
    wx.request({
      url: 'http://music.163.com/api/song/lyric?os=pc&id='+id+'&lv=-1&kv=-1&tv=-1',
      success:function(res){
        // console.log(id,res); 
        var lyric=res.data.lrc.lyric;
        // console.log(lyric);
        that.parseLyric(lyric);
      }
    })
    
   
  },
  //解析歌词
  parseLyric:function(lyric){
    //根据换行符将lyric分割成每句歌词的数组
    var lyricArray=lyric.split("\n");
    // 

    // 2.判定最后一句是否为空，如果是则删除
    if(lyricArray[lyricArray.length-1]==''){
      // 删除数组的最后一个元素
      lyricArray.pop();
      // c
    }
    // 定义数组，存储最终歌词的结果
    var finalResult=[];
    //遍历lyricArray
    //v:数组中的每一个元素 i：每个元素的对应下标 a：遍历数组的本身
        // console.log(lyric,lyricArray);
        lyricArray.forEach(function(v,i,a){
      // trim():去掉左右两端的空格
      var lyricText=v.split("]")[1].trim();
      // console.log(lyricArray);
    
      // 空歌词不要
      if(lyricText!=''){
        var timeStr=v.split("]")[0].replace("[","");
        //将时间转换为秒，统一时间
        var time=parseFloat(timeStr.split(":")[0]*60+timeStr.split(":")[1]);
        // 将时间和歌词添加到finalResult中
        finalResult.push([time,lyricText]);
        // console.log(finalResult);
      }
    })
    // console.log(lyricArray);
    this.setData({
      lyricArray:finalResult
    })
  },
  /**歌词滚动 */ 
  lyricScroll:function(){
    // 1.获取当前音频的进度和时长
    var currentTime=innerAudioContext.currentTime;
    // console.log(currentTime);
    //2.获取当前播放的总进度
    var duration=innerAudioContext.duration;
    // 2.获取歌词的数组
    var lyricArray=this.data.lyricArray;
    //判断
    if(lyricArray!=null){
      // currentIndex取值为倒数第二句歌词的下标时，同时音频的进度还要满足大于最后一句歌词的起始时间
      if(this.data.currentIndex>=lyricArray.length-2&&currentTime>=lyricArray[lyricArray.length-1][0]){
        // 该行是正在播放的一行，字体颜色变为红色
        // 给currentIndex赋值长度减一
        this.setData({
          currentIndex:lyricArray.length-1,
        })
      }else{
        //遍历所有歌词的时间
        //只适用于第一句到倒数第二句，最后一句单独判断
        for(var i=0;i<lyricArray.length-1;i++){
          //当前音频进度要满足 大于等于当前行时间，且小于下一行的时间
          if(currentTime>=lyricArray[i][0] && currentTime<lyricArray[i+1][0]){
            // i是几， 让那几句变红
            this.setData({
              currentIndex:i
            })
          }
        }
      }
      // 设置歌词前7行不滚动
      if(this.data.currentIndex>6){
        this.setData({
          scrollTop:(this.data.currentIndex-6)*30
        })
      }else{
        this.setData({
          scrollTop:0
        })
      }
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})